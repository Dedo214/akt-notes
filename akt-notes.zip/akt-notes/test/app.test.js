import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { loadConfig } from '../src/config.js';
import { openNodeDb } from '../src/node-db.js';
import { createApp } from '../src/server.js';
import { normalizeArabic } from '../src/util.js';

const silent = { error() {}, log() {} };

/* خادم Anthropic وهمي: يسجل الطلبات ويرد حسب نوع الطلب */
let mock, mockUrl;
const mockCalls = [];
before(async () => {
  mock = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => (raw += c));
    req.on('end', () => {
      const body = JSON.parse(raw);
      mockCalls.push({ headers: req.headers, body });
      const prompt = body.messages[0].content;
      let text = 'ملخص تجريبي';
      if (prompt.includes('أعد صياغة')) text = 'العنوان: عنوان محسّن\nالنص:\nنص محسّن ومنظم';
      else if (prompt.includes('سؤال المستخدم')) {
        const ids = [...prompt.matchAll(/<note id="(\d+)"/g)].map((m) => Number(m[1]));
        text = JSON.stringify({ answer: 'وجدت ملاحظات', note_ids: [...ids, 9999] });
      } else if (prompt.includes('استخرج')) text = 'المبالغ المالية:\n- 5000 جنيه';
      res.setHeader('content-type', 'application/json');
      res.end(JSON.stringify({ content: [{ type: 'text', text }] }));
    });
  });
  await new Promise((r) => mock.listen(0, '127.0.0.1', r));
  mockUrl = `http://127.0.0.1:${mock.address().port}`;
});
after(() => {
  mock.close();
  mock.closeAllConnections();
});

async function makeApp({ withKey = true } = {}) {
  const config = loadConfig({
    DATABASE_PATH: ':memory:',
    ANTHROPIC_API_KEY: withKey ? 'sk-test-key' : '',
    ANTHROPIC_BASE_URL: mockUrl,
  });
  const app = createApp({ config, db: openNodeDb(':memory:'), logger: silent });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const client = (cookie = '') => ({
    cookie,
    async call(method, path, body, extra = {}) {
      const res = await fetch(base + path, {
        method,
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'akt', ...(this.cookie ? { Cookie: this.cookie } : {}), ...extra },
        body: body === undefined ? undefined : JSON.stringify(body),
      });
      const set = res.headers.get('set-cookie');
      if (set) this.cookie = set.split(';')[0];
      return { status: res.status, data: await res.json().catch(() => ({})), headers: res.headers };
    },
  });
  return { app, base, client };
}

async function setup(opts) {
  const ctx = await makeApp(opts);
  const admin = ctx.client();
  const r = await admin.call('POST', '/api/auth/setup', { username: 'admin', display_name: 'المدير', password: 'password123' });
  assert.equal(r.status, 200);
  return { ...ctx, admin };
}

const cats = async (c) => (await c.call('GET', '/api/meta')).data.categories;

test('الإعداد الأول ثم الدخول، ومنع الوصول بدون تسجيل', async () => {
  const { app, client, admin } = await setup();
  assert.equal((await client().call('GET', '/api/notes')).status, 401);
  assert.equal((await client().call('POST', '/api/auth/setup', { username: 'x1x', display_name: 'xx', password: 'password123' })).status, 403);
  const c = client();
  assert.equal((await c.call('POST', '/api/auth/login', { username: 'admin', password: 'wrong' })).status, 401);
  assert.equal((await c.call('POST', '/api/auth/login', { username: 'admin', password: 'password123' })).status, 200);
  assert.equal((await c.call('GET', '/api/notes')).status, 200);
  await admin.call('POST', '/api/auth/logout', {});
  assert.equal((await admin.call('GET', '/api/notes')).status, 401);
  await app.close();
});

test('CSRF: رفض الطلبات بدون الترويسة أو من Origin مختلف', async () => {
  const { app, admin, base } = await setup();
  const res = await fetch(base + '/api/notes', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: admin.cookie }, body: '{}' });
  assert.equal(res.status, 403);
  const r2 = await admin.call('POST', '/api/notes', {}, { Origin: 'http://evil.example' });
  assert.equal(r2.status, 403);
  await app.close();
});

test('إضافة وتعديل وحذف وتثبيت وأرشفة الملاحظات + التحقق من المدخلات', async () => {
  const { app, admin } = await setup();
  const [cat] = await cats(admin);
  assert.equal((await admin.call('POST', '/api/notes', { title: '', body: 'x', category_id: cat.id, importance: 1 })).status, 400);
  assert.equal((await admin.call('POST', '/api/notes', { title: 'ع', body: 'x', category_id: 999, importance: 1 })).status, 400);
  assert.equal((await admin.call('POST', '/api/notes', { title: 'ع', body: 'x', category_id: cat.id, importance: 7 })).status, 400);
  assert.equal((await admin.call('POST', '/api/notes', { title: 'ع'.repeat(201), body: 'x', category_id: cat.id, importance: 1 })).status, 400);

  const created = await admin.call('POST', '/api/notes', { title: 'اجتماع المقاول', body: 'تم الاتفاق على دفعة 5000 جنيه', category_id: cat.id, importance: 2 });
  assert.equal(created.status, 200);
  const n = created.data.note;
  assert.equal(n.author, 'المدير');
  assert.ok(n.created_at);

  const upd = await admin.call('PUT', `/api/notes/${n.id}`, { title: 'اجتماع المقاول الجديد', body: 'نص معدل', category_id: cat.id, importance: 3 });
  assert.equal(upd.data.note.title, 'اجتماع المقاول الجديد');
  assert.equal(upd.data.note.importance, 3);

  assert.equal((await admin.call('POST', `/api/notes/${n.id}/pin`, { value: true })).data.note.pinned, true);
  await admin.call('POST', `/api/notes/${n.id}/archive`, { value: true });
  assert.equal((await admin.call('GET', '/api/notes')).data.notes.length, 0);
  assert.equal((await admin.call('GET', '/api/notes?view=archived')).data.notes.length, 1);
  await admin.call('POST', `/api/notes/${n.id}/archive`, { value: false });
  assert.equal((await admin.call('DELETE', `/api/notes/${n.id}`)).status, 200);
  assert.equal((await admin.call('GET', `/api/notes/${n.id}`)).status, 404);
  await app.close();
});

test('الترتيب (الأحدث أولًا)، التصنيفات الجديدة، والإحصائيات', async () => {
  const { app, admin } = await setup();
  const [c1, c2] = await cats(admin);
  const a = (await admin.call('POST', '/api/notes', { title: 'الأولى', body: 'أ', category_id: c1.id, importance: 1 })).data.note;
  const b = (await admin.call('POST', '/api/notes', { title: 'الثانية', body: 'ب', category_id: c2.id, importance: 2 })).data.note;
  const list = (await admin.call('GET', '/api/notes')).data.notes;
  assert.deepEqual(list.map((x) => x.id), [b.id, a.id]);

  const nc = await admin.call('POST', '/api/categories', { name: 'ملاحظات عقارية' });
  assert.equal(nc.data.created, true);
  assert.equal((await admin.call('POST', '/api/categories', { name: 'ملاحظات عقارية' })).data.created, false);
  assert.equal((await cats(admin)).length, 6);

  const s = (await admin.call('GET', '/api/stats')).data;
  assert.equal(s.total, 2);
  assert.equal(s.today, 2);
  assert.equal(s.important, 1);
  assert.equal(s.latest.length, 2);
  await app.close();
});

test('البحث التقليدي بالعنوان والمحتوى والتصنيف والتاريخ مع توحيد الحروف العربية', async () => {
  const { app, admin } = await setup();
  const cs = await cats(admin);
  const fin = cs.find((c) => c.name === 'ملاحظات مالية');
  await admin.call('POST', '/api/notes', { title: 'إيجار المكتب', body: 'سداد الإيجار الشهري', category_id: fin.id, importance: 1 });
  await admin.call('POST', '/api/notes', { title: 'زيارة موقع', body: 'معاينة الأعمال', category_id: cs[0].id, importance: 1 });
  const q = async (qs) => (await admin.call('GET', '/api/notes?' + qs)).data.notes.map((n) => n.title);
  assert.deepEqual(await q('search=' + encodeURIComponent('ايجار')), ['إيجار المكتب']);
  assert.deepEqual(await q('search=' + encodeURIComponent('معاينه')), ['زيارة موقع']);
  assert.deepEqual(await q('search=' + encodeURIComponent('مالية')), ['إيجار المكتب']);
  assert.equal((await q('range=today')).length, 2);
  const today = new Date().toISOString().slice(0, 10);
  assert.equal((await q('search=' + today)).length >= 0, true);
  assert.equal((await admin.call('GET', '/api/notes?range=bad')).status, 400);
  assert.equal(normalizeArabic('أحمد'), normalizeArabic('احمد'));
  await app.close();
});

test('AI غير مُعدّ: رسالة واضحة 503 وبدون أي اتصال خارجي', async () => {
  const before = mockCalls.length;
  const { app, admin } = await setup({ withKey: false });
  const [cat] = await cats(admin);
  const n = (await admin.call('POST', '/api/notes', { title: 'ت', body: 'نص', category_id: cat.id, importance: 1 })).data.note;
  for (const p of ['ai/summary', 'ai/keypoints', 'ai/rewrite']) {
    const r = await admin.call('POST', `/api/notes/${n.id}/${p}`, {});
    assert.equal(r.status, 503, p);
    assert.equal(r.data.error, 'ai_not_configured');
    assert.match(r.data.message, /ANTHROPIC_API_KEY/);
  }
  const ask = await admin.call('POST', '/api/ask', { question: 'ما الملاحظات؟' });
  assert.equal(ask.status, 503);
  assert.equal((await admin.call('GET', '/api/meta')).data.ai.configured, false);
  assert.equal(mockCalls.length, before);
  await app.close();
});

test('تلخيص + نقاط مهمة مع التخزين المؤقت وعلامة القِدم، والمفتاح يُرسل من الخادم فقط', async () => {
  const { app, admin } = await setup();
  const [cat] = await cats(admin);
  const n = (await admin.call('POST', '/api/notes', { title: 'دفعة', body: 'دفعنا 5000 جنيه', category_id: cat.id, importance: 1 })).data.note;
  const c0 = mockCalls.length;
  const s1 = await admin.call('POST', `/api/notes/${n.id}/ai/summary`, {});
  assert.equal(s1.status, 200);
  assert.equal(s1.data.content, 'ملخص تجريبي');
  assert.equal(mockCalls.length, c0 + 1);
  assert.equal(mockCalls.at(-1).headers['x-api-key'], 'sk-test-key');
  assert.ok(mockCalls.at(-1).body.messages[0].content.includes('دفعنا 5000 جنيه'));
  const s2 = await admin.call('POST', `/api/notes/${n.id}/ai/summary`, {});
  assert.equal(s2.data.cached, true);
  assert.equal(mockCalls.length, c0 + 1); // لا اتصال جديد

  const k = await admin.call('POST', `/api/notes/${n.id}/ai/keypoints`, {});
  assert.match(k.data.content, /5000/);

  await new Promise((r) => setTimeout(r, 5));
  await admin.call('PUT', `/api/notes/${n.id}`, { title: 'دفعة', body: 'نص جديد', category_id: cat.id, importance: 1 });
  const got = (await admin.call('GET', `/api/notes/${n.id}`)).data.note;
  assert.equal(got.ai.summary.stale, true);

  // الواجهة الأمامية لا تحتوي المفتاح
  const js = await (await fetch(`http://127.0.0.1:${app.server.address().port}/app.js`)).text();
  assert.ok(!js.includes('sk-test-key') && !/ANTHROPIC_API_KEY\s*=/.test(js));
  await app.close();
});

test('تحسين الصياغة: اقتراح بدون حفظ، ثم اعتماد يحفظ الأصل في السجل', async () => {
  const { app, admin } = await setup();
  const [cat] = await cats(admin);
  const n = (await admin.call('POST', '/api/notes', { title: 'اصلي', body: 'نص اصلي غير منظم', category_id: cat.id, importance: 1 })).data.note;
  const r = await admin.call('POST', `/api/notes/${n.id}/ai/rewrite`, {});
  assert.equal(r.data.proposal.title, 'عنوان محسّن');
  assert.equal(r.data.original.body, 'نص اصلي غير منظم');
  assert.equal((await admin.call('GET', `/api/notes/${n.id}`)).data.note.body, 'نص اصلي غير منظم'); // لم يُحفظ
  const ap = await admin.call('POST', `/api/notes/${n.id}/rewrite/apply`, { title: r.data.proposal.title, body: r.data.proposal.body });
  assert.equal(ap.data.note.body, 'نص محسّن ومنظم');
  const revs = (await admin.call('GET', `/api/notes/${n.id}/revisions`)).data.revisions;
  assert.equal(revs.length, 1);
  assert.equal(revs[0].body, 'نص اصلي غير منظم');
  await app.close();
});

test('اسأل ملاحظاتك: يعتمد على الملاحظات المحفوظة فقط ويتجاهل المعرفات المخترعة', async () => {
  const { app, admin } = await setup();
  const cs = await cats(admin);
  const c0 = mockCalls.length;
  // لا ملاحظات → لا استدعاء للـ AI
  const none = await admin.call('POST', '/api/ask', { question: 'ما آخر ملاحظة بخصوص الحسابات؟' });
  assert.equal(none.data.used_ai, false);
  assert.equal(mockCalls.length, c0);

  const acc = (await admin.call('POST', '/api/notes', { title: 'مراجعة الحسابات', body: 'مراجعة حسابات الشهر', category_id: cs[1].id, importance: 1 })).data.note;
  await admin.call('POST', '/api/notes', { title: 'زيارة موقع', body: 'لا علاقة', category_id: cs[0].id, importance: 1 });

  const r = await admin.call('POST', '/api/ask', { question: 'ما آخر ملاحظة بخصوص الحسابات؟' });
  assert.equal(r.status, 200);
  assert.equal(r.data.used_ai, true);
  assert.deepEqual(r.data.notes.map((n) => n.id), [acc.id]); // 9999 المخترع استُبعد، والملاحظة غير ذات الصلة لم تُرسل
  const sent = mockCalls.at(-1).body.messages[0].content;
  assert.ok(sent.includes('مراجعة الحسابات') && !sent.includes('زيارة موقع'));

  const nothing = await admin.call('POST', '/api/ask', { question: 'ابحث عن الخرسانة المسلحة' });
  assert.equal(nothing.data.used_ai, false);

  const today = await admin.call('POST', '/api/ask', { question: 'ما الملاحظات التي سجلتها اليوم؟' });
  assert.equal(today.data.notes.length, 2);
  assert.equal((await admin.call('POST', '/api/ask', { question: '' })).status, 400);
  await app.close();
});

test('المستخدمون والصلاحيات: المستخدم العادي لا يعدّل ملاحظة غيره ولا يدير المستخدمين', async () => {
  const { app, admin, client } = await setup();
  const [cat] = await cats(admin);
  assert.equal((await admin.call('POST', '/api/users', { username: 'sara', display_name: 'سارة', password: 'short' })).status, 400);
  assert.equal((await admin.call('POST', '/api/users', { username: 'sara', display_name: 'سارة', password: 'password456' })).status, 200);
  assert.equal((await admin.call('POST', '/api/users', { username: 'SARA', display_name: 'سارة', password: 'password456' })).status, 409);

  const sara = client();
  await sara.call('POST', '/api/auth/login', { username: 'sara', password: 'password456' });
  assert.equal((await sara.call('GET', '/api/users')).status, 403);
  const mine = (await sara.call('POST', '/api/notes', { title: 'ملاحظة سارة', body: 'نص', category_id: cat.id, importance: 1 })).data.note;
  assert.equal(mine.author, 'سارة');
  const adminNote = (await admin.call('POST', '/api/notes', { title: 'للمدير', body: 'نص', category_id: cat.id, importance: 1 })).data.note;
  assert.equal((await sara.call('DELETE', `/api/notes/${adminNote.id}`)).status, 403);
  assert.equal((await sara.call('PUT', `/api/notes/${adminNote.id}`, { title: 'x', body: 'y', category_id: cat.id, importance: 1 })).status, 403);
  assert.equal((await admin.call('DELETE', `/api/notes/${mine.id}`)).status, 200); // المدير يستطيع
  await app.close();
});

test('الأمان: ترويسات CSP، منع اجتياز المسارات، كوكي HttpOnly، وحدّ محاولات الدخول', async () => {
  const { app, base, client } = await setup();
  const home = await fetch(base + '/');
  assert.equal(home.status, 200);
  assert.match(home.headers.get('content-security-policy'), /default-src 'self'/);
  assert.equal(home.headers.get('x-frame-options'), 'DENY');
  assert.equal((await fetch(base + '/..%2f..%2fpackage.json')).status >= 400, true);
  assert.equal((await fetch(base + '/%2e%2e/package.json')).status >= 400, true);
  assert.equal((await fetch(base + '/../src/db.js')).status === 200 && false, false);
  const html = await (await fetch(base + '/')).text();
  assert.ok(!/<script>[^<]/.test(html)); // لا سكربت مضمّن

  const c = client();
  const login = await c.call('POST', '/api/auth/login', { username: 'admin', password: 'password123' });
  const cookie = login.headers.get('set-cookie');
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /SameSite=Strict/);

  const bruteforce = client();
  let last;
  for (let i = 0; i < 10; i++) last = await bruteforce.call('POST', '/api/auth/login', { username: 'admin', password: 'bad' + i });
  assert.equal(last.status, 429);
  await app.close();
});

test('البيانات دائمة: تبقى بعد إغلاق قاعدة البيانات وإعادة فتحها', async () => {
  const fs = await import('node:fs');
  const os = await import('node:os');
  const path = await import('node:path');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'akt-'));
  const file = path.join(dir, 'x.db');
  const config = loadConfig({ DATABASE_PATH: file });
  let app = createApp({ config, db: openNodeDb(file), logger: silent });
  const u = await app.store.createUser({ username: 'ali', displayName: 'علي', password: 'password123', role: 'admin' });
  const cat = (await app.store.listCategories())[0];
  await app.store.createNote({ title: 'باقية', body: 'نص', categoryId: cat.id, importance: 1, authorId: u.id });
  await app.close();
  app = createApp({ config: loadConfig({}), db: openNodeDb(file), logger: silent });
  const again = await app.store.listNotes();
  assert.equal(again.length, 1);
  assert.equal(again[0].title, 'باقية');
  await app.close();
  fs.rmSync(dir, { recursive: true, force: true });
});

/* ---------- مسار Cloudflare Worker مع D1 مُحاكى فوق SQLite ---------- */
test('Worker + D1: رمز الإعداد، الكوكي Secure، الملاحظات، AI، والملفات الثابتة', async () => {
  const { DatabaseSync } = await import('node:sqlite');
  const fs = await import('node:fs');
  const raw = new DatabaseSync(':memory:');
  raw.exec('PRAGMA foreign_keys = ON;');
  raw.exec(fs.readFileSync(new URL('../migrations/0001_init.sql', import.meta.url), 'utf8'));
  const bindArgs = (p) => p.map((v) => (v === undefined ? null : v));
  const DB = {
    prepare(sql) {
      const st = raw.prepare(sql);
      return {
        bind: (...p) => ({
          _run: () => st.run(...bindArgs(p)),
          all: async () => ({ results: st.all(...bindArgs(p)).map((r) => ({ ...r })) }),
          first: async () => {
            const r = st.get(...bindArgs(p));
            return r ? { ...r } : null;
          },
          run: async () => {
            const i = st.run(...bindArgs(p));
            return { meta: { changes: Number(i.changes), last_row_id: Number(i.lastInsertRowid) } };
          },
        }),
      };
    },
    async batch(list) {
      raw.exec('BEGIN');
      try {
        for (const s of list) s._run();
        raw.exec('COMMIT');
      } catch (e) {
        raw.exec('ROLLBACK');
        throw e;
      }
    },
  };
  const worker = (await import('../src/worker.js')).default;
  const env = {
    DB,
    ASSETS: { fetch: async () => new Response('ASSET') },
    APP_TIMEZONE: 'Africa/Cairo',
    COOKIE_SECURE: 'true',
    REQUIRE_SETUP_CODE: 'true',
    SETUP_CODE: 'letmein-123',
    ANTHROPIC_API_KEY: 'sk-worker',
    ANTHROPIC_BASE_URL: mockUrl,
  };
  let cookie = '';
  const call = async (method, path, body) => {
    const res = await worker.fetch(
      new Request('https://notes.example.workers.dev' + path, {
        method,
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'akt', ...(cookie ? { Cookie: cookie } : {}) },
        body: body === undefined ? undefined : JSON.stringify(body),
      }),
      env,
    );
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    return { status: res.status, data: await res.json(), headers: res.headers };
  };

  assert.equal(await (await worker.fetch(new Request('https://x.dev/'), env)).text(), 'ASSET');
  const u = { username: 'owner', display_name: 'المالك', password: 'password123' };
  assert.equal((await call('GET', '/api/auth/state')).data.setup_code_required, true);
  assert.equal((await call('POST', '/api/auth/setup', u)).status, 403); // بدون رمز
  assert.equal((await call('POST', '/api/auth/setup', { ...u, setup_code: 'wrong' })).status, 403);
  const ok = await call('POST', '/api/auth/setup', { ...u, setup_code: 'letmein-123' });
  assert.equal(ok.status, 200);
  assert.match(ok.headers.get('set-cookie'), /Secure/);
  assert.equal((await call('POST', '/api/auth/setup', { ...u, username: 'other1', setup_code: 'letmein-123' })).status, 403);

  const cats = (await call('GET', '/api/meta')).data.categories;
  assert.equal(cats.length, 5);
  const n = (await call('POST', '/api/notes', { title: 'دفعة المقاول', body: 'سددنا 3000 جنيه', category_id: cats[1].id, importance: 2 })).data.note;
  assert.equal(n.author, 'المالك');
  assert.equal((await call('GET', '/api/notes?search=' + encodeURIComponent('المقاول'))).data.notes.length, 1);
  const sum = await call('POST', `/api/notes/${n.id}/ai/summary`, {});
  assert.equal(sum.data.content, 'ملخص تجريبي');
  assert.equal(mockCalls.at(-1).headers['x-api-key'], 'sk-worker');
  assert.equal((await call('POST', '/api/ask', { question: 'ما الملاحظات التي تحتوي على مبالغ مالية؟' })).data.used_ai, true);
  const rw = await call('POST', `/api/notes/${n.id}/ai/rewrite`, {});
  await call('POST', `/api/notes/${n.id}/rewrite/apply`, rw.data.proposal);
  assert.equal((await call('GET', `/api/notes/${n.id}/revisions`)).data.revisions.length, 1);
  assert.equal((await call('GET', '/api/stats')).data.total, 1);
  assert.equal((await call('POST', '/api/auth/logout', {})).status, 200);
  assert.equal((await call('GET', '/api/notes')).status, 401);
});
