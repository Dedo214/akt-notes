// خادم Node المحلي: يغلّف الـ handler الموحّد ويخدم الملفات الثابتة.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadConfig } from './config.js';
import { openNodeDb } from './node-db.js';
import { createStore } from './store.js';
import { createAi } from './ai.js';
import { createHandler, MAX_JSON_BYTES } from './app.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8',
};

const SECURITY_HEADERS = {
  'Content-Security-Policy':
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; " +
    "object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
};

export function createApp({
  config = loadConfig(process.env),
  db,
  ai,
  logger = console,
  publicDir = path.join(ROOT, 'public'),
} = {}) {
  const database = db || openNodeDb(process.env.DATABASE_PATH || path.join(ROOT, 'data', 'akt-notes.db'));
  const store = createStore(database, { timezone: config.timezone, pbkdf2Iterations: config.pbkdf2Iterations });
  const aiClient = ai || createAi({ config, logger });
  const handle = createHandler({ config, store, ai: aiClient, logger });

  const clientIp = (req) =>
    (config.trustProxy && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) ||
    req.socket.remoteAddress ||
    'unknown';

  function serveStatic(req, res, pathname) {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405, { Allow: 'GET, HEAD' });
      return res.end();
    }
    let rel;
    try {
      rel = decodeURIComponent(pathname);
    } catch {
      res.writeHead(400);
      return res.end();
    }
    if (rel === '/' || rel === '') rel = '/index.html';
    const file = path.normalize(path.join(publicDir, rel));
    if (!file.startsWith(publicDir + path.sep)) {
      res.writeHead(403);
      return res.end();
    }
    fs.stat(file, (err, st) => {
      if (err || !st.isFile()) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        return res.end('غير موجود');
      }
      res.writeHead(200, {
        'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
        'Content-Length': st.size,
        'Cache-Control': 'no-cache',
      });
      if (req.method === 'HEAD') return res.end();
      fs.createReadStream(file).pipe(res);
    });
  }

  function readBody(req) {
    return new Promise((resolve, reject) => {
      const chunks = [];
      let size = 0;
      req.on('data', (c) => {
        size += c.length;
        if (size > MAX_JSON_BYTES * 2) {
          reject(Object.assign(new Error('too large'), { tooLarge: true }));
          req.destroy();
          return;
        }
        chunks.push(c);
      });
      req.on('end', () => resolve(Buffer.concat(chunks)));
      req.on('error', reject);
    });
  }

  const server = http.createServer(async (req, res) => {
    for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
    try {
      const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
      if (!url.pathname.startsWith('/api/')) return serveStatic(req, res, url.pathname);

      const headers = new Headers();
      for (const [k, v] of Object.entries(req.headers)) headers.set(k, Array.isArray(v) ? v.join(', ') : v);
      const hasBody = req.method !== 'GET' && req.method !== 'HEAD';
      const body = hasBody ? await readBody(req) : undefined;
      const request = new Request(url, { method: req.method, headers, body: body?.length ? body : undefined });

      const r = await handle(request, { ip: clientIp(req) });
      const out = Buffer.from(await r.arrayBuffer());
      const outHeaders = Object.fromEntries(r.headers);
      delete outHeaders['set-cookie'];
      const cookies = r.headers.getSetCookie();
      if (cookies.length) outHeaders['set-cookie'] = cookies;
      outHeaders['content-length'] = out.length;
      res.writeHead(r.status, outHeaders);
      res.end(out);
    } catch (e) {
      if (!res.headersSent) {
        res.writeHead(e?.tooLarge ? 413 : 500, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ error: e?.tooLarge ? 'too_large' : 'server', message: e?.tooLarge ? 'حجم الطلب كبير جدًا' : 'حدث خطأ غير متوقع في الخادم' }));
      }
      if (!e?.tooLarge) logger.error('[server]', e);
    }
  });
  server.requestTimeout = 120000;

  return {
    server,
    store,
    config,
    ai: aiClient,
    close: () =>
      new Promise((resolve) => {
        server.close(() => {
          try {
            database.close?.();
          } catch {
            /* مغلقة */
          }
          resolve();
        });
        server.closeAllConnections?.();
      }),
  };
}

/* ---------- التشغيل ---------- */

function loadDotEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (!m || line.trim().startsWith('#')) continue;
    const v = m[2].replace(/^(['"])(.*)\1$/, '$2');
    if (!(m[1] in process.env)) process.env[m[1]] = v;
  }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  loadDotEnv(path.join(ROOT, '.env'));
  const app = createApp({ config: loadConfig(process.env) });
  const { config, store } = app;

  // إنشاء مدير أول تلقائيًا إن تم تحديده في البيئة
  if (!(await store.hasUsers()) && process.env.ADMIN_USERNAME && process.env.ADMIN_PASSWORD) {
    await store.createUser({
      username: process.env.ADMIN_USERNAME,
      displayName: process.env.ADMIN_NAME || process.env.ADMIN_USERNAME,
      password: process.env.ADMIN_PASSWORD,
      role: 'admin',
    });
    console.log('تم إنشاء حساب المدير من متغيرات البيئة.');
  }

  app.server.listen(config.port, config.host, async () => {
    console.log(`AKT Group Office Notes AI يعمل على http://${config.host}:${config.port}`);
    console.log(app.ai.configured ? `الذكاء الاصطناعي: مُفعّل (${config.ai.model})` : 'الذكاء الاصطناعي: غير مُعدّ (ANTHROPIC_API_KEY مفقود)');
    if (!(await store.hasUsers())) console.log('افتح الصفحة لإنشاء حساب المدير الأول.');
  });
  const stop = () => app.close().then(() => process.exit(0));
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}
