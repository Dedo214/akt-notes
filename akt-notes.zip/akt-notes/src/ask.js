// اختيار الملاحظات ذات الصلة بسؤال المستخدم قبل إرسالها للذكاء الاصطناعي.
// يعتمد فقط على الملاحظات المحفوظة فعلًا؛ إن لم توجد نتائج لا يُستدعى الـ AI أصلًا.
import { normalizeArabic, searchTerms, localDay, addDays } from './util.js';

const STOP = new Set(
  [
    'ما', 'ماذا', 'هل', 'التي', 'الذي', 'الذين', 'اللي', 'كل', 'لي', 'عن', 'في', 'من', 'الى', 'على', 'علي', 'هو', 'هي',
    'ملاحظه', 'ملاحظات', 'الملاحظات', 'الملاحظه', 'ملاحظاتي', 'ملاحظاتى', 'سجلت', 'سجلتها', 'سجلتهم', 'كتبت', 'كتبتها',
    'اعرض', 'اعرضلي', 'اظهر', 'لخص', 'لخصلي', 'ابحث', 'ابحثلي', 'بخصوص', 'حول', 'عندي', 'عندى', 'يوجد', 'توجد',
    'الخاصه', 'الخاص', 'الخاصة', 'المتعلقه', 'المتعلق', 'تتعلق', 'يتعلق', 'تحتوي', 'تحتوى', 'يحتوي', 'اخر', 'اخرى', 'اي',
    'ايه', 'فيها', 'فيه', 'بها', 'به', 'موضوع', 'معين', 'معينه', 'هذا', 'هذه', 'ذلك', 'مع', 'او', 'و', 'ان', 'كان', 'كانت',
  ].map(normalizeArabic),
);
const AMOUNT_WORDS = new Set(
  ['مبلغ', 'مبالغ', 'المبالغ', 'المبلغ', 'ماليه', 'ماليه', 'فلوس', 'تكلفه', 'سعر', 'اسعار', 'جنيه', 'ريال', 'دولار', 'درهم', 'مالي'].map(
    normalizeArabic,
  ),
);
const DAY_WORDS = new Set(['اليوم', 'النهارده', 'امس', 'اسبوع', 'الاسبوع', 'اسبوعي', 'شهر', 'الشهر', 'شهري', 'الاسبوعيه'].map(normalizeArabic));
const MINE = /سجلت|كتبت|ملاحظاتي|ملاحظاتى/;

const strip = (t) => (t.length > 4 && t.startsWith('ال') ? t.slice(2) : t);

export async function selectNotesForQuestion({ store, question, user, timezone, maxNotes = 30 }) {
  const norm = normalizeArabic(question);
  const today = localDay(new Date(), timezone);

  let from = null;
  let to = null;
  let rangeLabel = 'كل الفترات';
  if (/امس/.test(norm)) {
    from = to = addDays(today, -1);
    rangeLabel = `أمس (${from})`;
  } else if (/اليوم|النهارده/.test(norm)) {
    from = to = today;
    rangeLabel = `اليوم (${today})`;
  } else if (/اسبوع/.test(norm)) {
    from = addDays(today, -6);
    to = today;
    rangeLabel = `آخر 7 أيام (${from} إلى ${to})`;
  } else if (/شهر/.test(norm)) {
    from = addDays(today, -29);
    to = today;
    rangeLabel = `آخر 30 يومًا (${from} إلى ${to})`;
  }

  const wantsAmounts = searchTerms(question).some((t) => AMOUNT_WORDS.has(t));
  const mineOnly = MINE.test(question);

  const terms = searchTerms(question)
    .filter((t) => !STOP.has(t) && !AMOUNT_WORDS.has(t) && !DAY_WORDS.has(t))
    .map(strip)
    .filter((t) => t.length >= 2);

  let notes = await store.listNotes({ view: 'all', from, to, limit: 2000 });
  if (mineOnly) notes = notes.filter((n) => n.author_id === user.id);
  if (wantsAmounts) {
    notes = notes.filter((n) => /\d/.test(normalizeArabic(n.title + ' ' + n.body)));
  }

  let picked;
  if (terms.length) {
    const scored = [];
    for (const n of notes) {
      const title = normalizeArabic(n.title);
      const rest = normalizeArabic([n.body, n.category, n.author].join(' '));
      let score = 0;
      for (const t of terms) {
        if (title.includes(t)) score += 3;
        if (rest.includes(t)) score += 1;
      }
      if (score > 0) scored.push({ n, score });
    }
    scored.sort((a, b) => b.score - a.score || (a.n.created_at < b.n.created_at ? 1 : -1));
    picked = scored.slice(0, maxNotes).map((s) => s.n);
  } else {
    picked = notes.slice(0, maxNotes); // مرتبة من الأحدث
  }

  const parts = [`الفترة: ${rangeLabel}`];
  if (mineOnly) parts.push(`ملاحظات المستخدم ${user.display_name} فقط`);
  if (wantsAmounts) parts.push('الملاحظات التي تحتوي على أرقام/مبالغ فقط');
  if (terms.length) parts.push(`كلمات البحث: ${terms.join('، ')}`);
  if (picked.length >= maxNotes) parts.push(`عُرض أحدث/أنسب ${maxNotes} ملاحظة فقط`);
  return { notes: picked, scope: parts.join(' — ') };
}
