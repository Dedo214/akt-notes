// منطق الـ API الموحّد: يستقبل Request قياسي ويرجع Response — يعمل على Node وعلى Cloudflare Workers.
import { IMPORTANCE } from './store.js';
import { AiError } from './ai.js';
import { selectNotesForQuestion } from './ask.js';
import { verifyPassword, hashPassword, safeEqual } from './crypto.js';
import { isDay } from './util.js';

export class HttpError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}
const bad = (message, code = 'invalid') => new HttpError(400, code, message);

const LIMITS = { title: 200, body: 20000, category: 50, question: 500, username: 30, display: 60 };
export const MAX_JSON_BYTES = 256 * 1024;
const COOKIE = 'akt_session';
const AI_NOT_CONFIGURED =
  'خدمة الذكاء الاصطناعي غير مُعدّة. أضف مفتاح ANTHROPIC_API_KEY (في ملف .env محليًا، أو كـ Secret على كلود فلير) ثم أعد التشغيل.';

let dummyHash;

function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) {
      try {
        out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
      } catch {
        /* تجاهل كوكي تالف */
      }
    }
  }
  return out;
}

async function readJson(request) {
  const type = String(request.headers.get('content-type') || '');
  if (!type.toLowerCase().startsWith('application/json')) {
    throw new HttpError(415, 'unsupported_media', 'نوع المحتوى يجب أن يكون JSON');
  }
  const len = Number(request.headers.get('content-length') || 0);
  if (len > MAX_JSON_BYTES) throw new HttpError(413, 'too_large', 'حجم الطلب كبير جدًا');
  const text = await request.text();
  if (new TextEncoder().encode(text).length > MAX_JSON_BYTES) throw new HttpError(413, 'too_large', 'حجم الطلب كبير جدًا');
  if (!text) return {};
  try {
    const v = JSON.parse(text);
    if (v === null || typeof v !== 'object' || Array.isArray(v)) throw new Error();
    return v;
  } catch {
    throw bad('صيغة JSON غير صالحة');
  }
}

function str(v, { min = 1, max, label }) {
  if (typeof v !== 'string') throw bad(`${label} مطلوب`);
  const s = v.replace(/\u0000/g, '').trim();
  if (s.length < min) throw bad(`${label} مطلوب`);
  if (s.length > max) throw bad(`${label} يجب ألا يتجاوز ${max} حرفًا`);
  return s;
}

export function createHandler({ config, store, ai, logger = console }) {
  const routes = [];
  const route = (method, pattern, handler, opts = {}) => {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:([a-z]+)/g, (_, k) => (keys.push(k), '([^/]+)')) + '$');
    routes.push({ method, re, keys, handler, public: !!opts.public });
  };

  const requireAdmin = (user) => {
    if (user.role !== 'admin') throw new HttpError(403, 'forbidden', 'هذه العملية للمدير فقط');
  };
  const getNote = async (id) => {
    const n = Number.isInteger(Number(id)) ? await store.getNote(Number(id)) : null;
    if (!n) throw new HttpError(404, 'not_found', 'الملاحظة غير موجودة');
    return n;
  };
  const canModify = (user, note) => user.role === 'admin' || note.author_id === user.id;
  const getModifiable = async (user, id) => {
    const note = await getNote(id);
    if (!canModify(user, note)) throw new HttpError(403, 'forbidden', 'يمكن لصاحب الملاحظة أو المدير فقط تنفيذ هذه العملية');
    return note;
  };
  const aiGuard = async (user) => {
    if (!ai.configured) throw new AiError(503, 'ai_not_configured', AI_NOT_CONFIGURED);
    const key = `ai:${user.id}`;
    if ((await store.rateCount(key, 60000)) >= 20) {
      throw new HttpError(429, 'rate_limited', 'عدد كبير من طلبات الذكاء الاصطناعي. انتظر دقيقة ثم حاول مرة أخرى.');
    }
    await store.rateAdd(key);
  };

  async function noteInput(b) {
    const title = str(b.title, { max: LIMITS.title, label: 'عنوان الملاحظة' });
    const body = str(b.body, { max: LIMITS.body, label: 'تفاصيل الملاحظة' });
    const categoryId = Number(b.category_id);
    if (!Number.isInteger(categoryId) || !(await store.getCategory(categoryId))) throw bad('التصنيف غير صالح');
    const importance = Number(b.importance ?? 1);
    if (![1, 2, 3].includes(importance)) throw bad('درجة الأهمية غير صالحة');
    return { title, body, categoryId, importance };
  }

  function userInput(b) {
    const username = str(b.username, { min: 3, max: LIMITS.username, label: 'اسم المستخدم' });
    if (!/^[A-Za-z0-9_.-]+$/.test(username)) throw bad('اسم المستخدم: حروف إنجليزية وأرقام و . _ - فقط');
    const displayName = str(b.display_name, { min: 2, max: LIMITS.display, label: 'الاسم الظاهر' });
    const password = typeof b.password === 'string' ? b.password : '';
    if (password.length < 8 || password.length > 200) throw bad('كلمة المرور يجب أن تكون 8 أحرف على الأقل');
    return { username, displayName, password };
  }

  const startSession = async (ctx, userId) => {
    const s = await store.createSession(userId);
    const parts = [`${COOKIE}=${s.token}`, 'Path=/', 'HttpOnly', 'SameSite=Strict', `Max-Age=${s.maxAgeSec}`];
    if (ctx.secure) parts.push('Secure');
    ctx.cookies.push(parts.join('; '));
  };

  /* ---------- المصادقة ---------- */

  route('GET', '/api/health', () => ({ ok: true }), { public: true });

  route('GET', '/api/auth/state', async (ctx) => ({
    has_users: await store.hasUsers(),
    user: ctx.user || null,
    setup_code_required: config.requireSetupCode || !!config.setupCode,
  }), { public: true });

  route('POST', '/api/auth/setup', async (ctx) => {
    if (await store.hasUsers()) throw new HttpError(403, 'forbidden', 'تم إعداد البرنامج مسبقًا');
    if (config.requireSetupCode && !config.setupCode) {
      throw new HttpError(503, 'setup_code_missing', 'لم يُضبط SETUP_CODE على الخادم. اضبطه أولًا ثم أعد المحاولة (راجع README).');
    }
    if (config.setupCode) {
      const given = typeof ctx.body.setup_code === 'string' ? ctx.body.setup_code.trim() : '';
      if (!safeEqual(given, config.setupCode)) throw new HttpError(403, 'bad_setup_code', 'رمز الإعداد غير صحيح');
    }
    const user = await store.createUser({ ...userInput(ctx.body), role: 'admin' });
    await startSession(ctx, user.id);
    return { user };
  }, { public: true });

  route('POST', '/api/auth/login', async (ctx) => {
    const username = typeof ctx.body.username === 'string' ? ctx.body.username.trim().slice(0, 60) : '';
    const password = typeof ctx.body.password === 'string' ? ctx.body.password.slice(0, 200) : '';
    const key = `login:${ctx.ip}|${username.toLowerCase()}`;
    if ((await store.rateCount(key, 15 * 60 * 1000)) >= 8) {
      throw new HttpError(429, 'locked', 'محاولات كثيرة خاطئة. حاول بعد 15 دقيقة.');
    }
    const row = await store.getUserByName(username);
    dummyHash ||= hashPassword('dummy-password-for-timing', config.pbkdf2Iterations);
    const ok = (await verifyPassword(password, row ? row.password_hash : await dummyHash)) && !!row;
    if (!ok) {
      await store.rateAdd(key);
      throw new HttpError(401, 'bad_credentials', 'اسم المستخدم أو كلمة المرور غير صحيحة');
    }
    await store.rateReset(key);
    await startSession(ctx, row.id);
    return { user: await store.getUserById(row.id) };
  }, { public: true });

  route('POST', '/api/auth/logout', async (ctx) => {
    await store.destroySession(ctx.token);
    ctx.cookies.push(`${COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0`);
    return { ok: true };
  });

  /* ---------- بيانات عامة ---------- */

  route('GET', '/api/meta', async () => ({
    categories: await store.listCategories(),
    importance: IMPORTANCE,
    timezone: config.timezone,
    ai: { configured: ai.configured },
  }));

  route('POST', '/api/categories', async (ctx) => {
    const name = str(ctx.body.name, { max: LIMITS.category, label: 'اسم التصنيف' });
    return store.addCategory(name);
  });

  route('GET', '/api/stats', () => store.stats());

  /* ---------- الملاحظات ---------- */

  route('GET', '/api/notes', async (ctx) => {
    const q = ctx.query;
    const range = q.get('range') || 'all';
    const view = q.get('view') || 'active';
    if (!['all', 'today', 'week', 'month'].includes(range)) throw bad('فلتر التاريخ غير صالح');
    if (!['active', 'archived', 'all'].includes(view)) throw bad('عرض غير صالح');
    const from = q.get('from');
    const to = q.get('to');
    if ((from && !isDay(from)) || (to && !isDay(to))) throw bad('تاريخ غير صالح');
    const categoryId = q.get('category') ? Number(q.get('category')) : null;
    const importance = q.get('importance') ? Number(q.get('importance')) : null;
    if (categoryId !== null && !Number.isInteger(categoryId)) throw bad('تصنيف غير صالح');
    if (importance !== null && ![1, 2, 3].includes(importance)) throw bad('درجة الأهمية غير صالحة');
    return { notes: await store.listNotes({ search: (q.get('search') || '').slice(0, 200), categoryId, importance, range, view, from, to }) };
  });

  route('POST', '/api/notes', async (ctx) => ({
    note: await store.createNote({ ...(await noteInput(ctx.body)), authorId: ctx.user.id }),
  }));

  route('GET', '/api/notes/:id', async (ctx) => ({ note: await getNote(ctx.params.id) }));

  route('PUT', '/api/notes/:id', async (ctx) => {
    await getModifiable(ctx.user, ctx.params.id);
    return { note: await store.updateNote(Number(ctx.params.id), await noteInput(ctx.body)) };
  });

  route('DELETE', '/api/notes/:id', async (ctx) => {
    await getModifiable(ctx.user, ctx.params.id);
    await store.deleteNote(Number(ctx.params.id));
    return { ok: true };
  });

  route('POST', '/api/notes/:id/pin', async (ctx) => {
    await getModifiable(ctx.user, ctx.params.id);
    return { note: await store.setPinned(Number(ctx.params.id), ctx.body.value !== false) };
  });

  route('POST', '/api/notes/:id/archive', async (ctx) => {
    await getModifiable(ctx.user, ctx.params.id);
    return { note: await store.setArchived(Number(ctx.params.id), ctx.body.value !== false) };
  });

  route('GET', '/api/notes/:id/revisions', async (ctx) => {
    await getNote(ctx.params.id);
    return { revisions: await store.listRevisions(Number(ctx.params.id)) };
  });

  /* ---------- الذكاء الاصطناعي ---------- */

  const aiCached = (kind, generate) => async (ctx) => {
    const note = await getNote(ctx.params.id);
    const cached = note.ai[kind];
    if (cached && !cached.stale && ctx.body.force !== true) return { kind, ...cached, cached: true };
    await aiGuard(ctx.user);
    const content = await generate(note);
    await store.saveAiResult(note.id, kind, content, note.updated_at);
    return { kind, content, stale: false, cached: false, created_at: new Date().toISOString() };
  };

  route('POST', '/api/notes/:id/ai/summary', aiCached('summary', (n) => ai.summarize(n)));
  route('POST', '/api/notes/:id/ai/keypoints', aiCached('keypoints', (n) => ai.keyPoints(n)));

  // اقتراح صياغة جديدة — لا يُحفظ شيء قبل اعتماد المستخدم
  route('POST', '/api/notes/:id/ai/rewrite', async (ctx) => {
    const note = await getModifiable(ctx.user, ctx.params.id);
    await aiGuard(ctx.user);
    const proposal = await ai.rewrite(note);
    return {
      original: { title: note.title, body: note.body },
      proposal: { title: proposal.title.slice(0, LIMITS.title), body: proposal.body.slice(0, LIMITS.body) },
      based_on: note.updated_at,
    };
  });

  route('POST', '/api/notes/:id/rewrite/apply', async (ctx) => {
    await getModifiable(ctx.user, ctx.params.id);
    const title = str(ctx.body.title, { max: LIMITS.title, label: 'العنوان' });
    const body = str(ctx.body.body, { max: LIMITS.body, label: 'النص' });
    return { note: await store.applyRewrite(Number(ctx.params.id), { title, body }) };
  });

  route('POST', '/api/ask', async (ctx) => {
    const question = str(ctx.body.question, { max: LIMITS.question, label: 'السؤال' });
    if (!ai.configured) await aiGuard(ctx.user); // يرمي رسالة عدم الإعداد
    const { notes, scope } = await selectNotesForQuestion({ store, question, user: ctx.user, timezone: config.timezone });
    if (!notes.length) {
      return { answer: 'لم أجد في الملاحظات المحفوظة ما يطابق سؤالك.', notes: [], used_ai: false };
    }
    await aiGuard(ctx.user);
    const result = await ai.ask({ question, notes, scope });
    const byId = new Map(notes.map((n) => [n.id, n]));
    const ids = [...new Set(result.noteIds)].filter((id) => byId.has(id));
    return {
      answer: result.answer,
      used_ai: true,
      notes: ids.map((id) => {
        const n = byId.get(id);
        return { id: n.id, title: n.title, category: n.category, created_at: n.created_at, author: n.author };
      }),
    };
  });

  /* ---------- المستخدمون ---------- */

  route('GET', '/api/users', async (ctx) => {
    requireAdmin(ctx.user);
    return { users: await store.listUsers() };
  });

  route('POST', '/api/users', async (ctx) => {
    requireAdmin(ctx.user);
    const input = userInput(ctx.body);
    if (await store.getUserByName(input.username)) throw new HttpError(409, 'exists', 'اسم المستخدم مستخدم من قبل');
    return { user: await store.createUser({ ...input, role: ctx.body.role === 'admin' ? 'admin' : 'user' }) };
  });

  /* ---------- المعالج ---------- */

  const baseHeaders = { 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer' };
  const respond = (status, data, cookies = []) => {
    const h = new Headers({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...baseHeaders });
    for (const c of cookies) h.append('Set-Cookie', c);
    return new Response(JSON.stringify(data), { status, headers: h });
  };

  return async function handle(request, { ip = 'unknown' } = {}) {
    const cookies = [];
    try {
      const url = new URL(request.url);
      const method = request.method;
      let matched = null;
      let pathExists = false;
      for (const r of routes) {
        const m = r.re.exec(url.pathname);
        if (!m) continue;
        pathExists = true;
        if (r.method !== method) continue;
        matched = { r, params: Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])])) };
        break;
      }
      if (!matched) {
        throw pathExists
          ? new HttpError(405, 'method_not_allowed', 'طريقة الطلب غير مسموحة')
          : new HttpError(404, 'not_found', 'المسار غير موجود');
      }

      const mutating = method !== 'GET' && method !== 'HEAD';
      if (mutating) {
        // حماية CSRF: ترويسة مخصصة + فحص Origin + SameSite=Strict
        if (request.headers.get('x-requested-with') !== 'akt') throw new HttpError(403, 'csrf', 'طلب غير مصرح به');
        const origin = request.headers.get('origin');
        if (origin) {
          const host =
            (config.trustProxy && request.headers.get('x-forwarded-host')) || request.headers.get('host') || url.host;
          let ok = false;
          try {
            ok = new URL(origin).host === host;
          } catch {
            /* غير صالح */
          }
          if (!ok) throw new HttpError(403, 'csrf', 'طلب غير مصرح به');
        }
      }

      const token = parseCookies(request.headers.get('cookie') || '')[COOKIE];
      const user = await store.getSession(token);
      if (!matched.r.public && !user) throw new HttpError(401, 'unauthorized', 'يرجى تسجيل الدخول');

      const secure =
        config.cookieSecure === 'true' ? true
        : config.cookieSecure === 'false' ? false
        : url.protocol === 'https:' || (config.trustProxy && request.headers.get('x-forwarded-proto') === 'https');

      const body = mutating ? await readJson(request) : {};
      const ctx = { request, url, params: matched.params, query: url.searchParams, body, user, token, ip, cookies, secure };
      return respond(200, await matched.r.handler(ctx), cookies);
    } catch (e) {
      if (e instanceof HttpError || e instanceof AiError) return respond(e.status, { error: e.code, message: e.message });
      if (/SQLITE|constraint|D1_ERROR/i.test(String(e?.message))) {
        logger.error('[db]', e);
        return respond(400, { error: 'db', message: 'تعذر حفظ البيانات. تحقق من المدخلات.' });
      }
      logger.error('[server]', e);
      return respond(500, { error: 'server', message: 'حدث خطأ غير متوقع في الخادم' });
    }
  };
}
