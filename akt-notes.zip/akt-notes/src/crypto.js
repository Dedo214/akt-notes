// تشفير كلمات المرور والرموز بواجهة WebCrypto (تعمل على Node وCloudflare Workers).
const enc = new TextEncoder();
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
const unhex = (h) => Uint8Array.from(h.match(/../g) || [], (x) => parseInt(x, 16));

export async function sha256Hex(s) {
  return hex(await crypto.subtle.digest('SHA-256', enc.encode(s)));
}

export function randomToken(bytes = 32) {
  const b = crypto.getRandomValues(new Uint8Array(bytes));
  return btoa(String.fromCharCode(...b)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function pbkdf2(password, salt, iterations) {
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256));
}

export function safeEqual(a, b) {
  const x = typeof a === 'string' ? enc.encode(a) : a;
  const y = typeof b === 'string' ? enc.encode(b) : b;
  let diff = x.length ^ y.length;
  for (let i = 0; i < Math.max(x.length, y.length); i++) diff |= (x[i] || 0) ^ (y[i] || 0);
  return diff === 0;
}

export async function hashPassword(password, iterations = 100000) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  return `pbkdf2$${iterations}$${hex(salt)}$${hex(await pbkdf2(password, salt, iterations))}`;
}

export async function verifyPassword(password, stored) {
  const parts = String(stored).split('$');
  if (parts[0] === 'pbkdf2' && parts.length === 4) {
    const iterations = Number(parts[1]);
    if (!Number.isInteger(iterations) || iterations < 1000 || iterations > 100000) return false;
    return safeEqual(await pbkdf2(password, unhex(parts[2]), iterations), unhex(parts[3]));
  }
  if (parts[0] === 'scrypt' && parts.length === 3) {
    // توافق مع قواعد بيانات قديمة أُنشئت على Node فقط
    try {
      const nodeCrypto = await import('node:crypto');
      const expected = Buffer.from(parts[2], 'hex');
      const actual = nodeCrypto.scryptSync(password, Buffer.from(parts[1], 'hex'), expected.length);
      return nodeCrypto.timingSafeEqual(expected, actual);
    } catch {
      return false;
    }
  }
  return false;
}
