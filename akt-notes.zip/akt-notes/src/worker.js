// نقطة دخول Cloudflare Workers: الـ API فقط (الملفات الثابتة تخدمها Workers Assets).
import { loadConfig } from './config.js';
import { d1Adapter } from './d1.js';
import { createStore } from './store.js';
import { createAi } from './ai.js';
import { createHandler } from './app.js';

let cached;
function init(env) {
  if (!cached) {
    const config = loadConfig(env);
    const store = createStore(d1Adapter(env.DB), { timezone: config.timezone, pbkdf2Iterations: config.pbkdf2Iterations });
    cached = createHandler({ config, store, ai: createAi({ config }) });
  }
  return cached;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/api/')) return env.ASSETS.fetch(request);
    return init(env)(request, { ip: request.headers.get('cf-connecting-ip') || 'unknown' });
  },
};
