// محوّل SQLite المحلي (Node) — نفس واجهة محوّل D1.
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

const SCHEMA = fs.readFileSync(new URL('../migrations/0001_init.sql', import.meta.url), 'utf8');

export function openNodeDb(dbPath) {
  if (dbPath !== ':memory:') fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA busy_timeout = 5000;');
  db.exec(SCHEMA);
  const cache = new Map();
  const stmt = (sql) => {
    if (!cache.has(sql)) cache.set(sql, db.prepare(sql));
    return cache.get(sql);
  };
  const run = (sql, p = []) => {
    const i = stmt(sql).run(...p);
    return { changes: Number(i.changes), lastId: Number(i.lastInsertRowid) };
  };
  return {
    all: async (sql, p = []) => stmt(sql).all(...p).map((r) => ({ ...r })),
    get: async (sql, p = []) => {
      const r = stmt(sql).get(...p);
      return r ? { ...r } : undefined;
    },
    run: async (sql, p = []) => run(sql, p),
    batch: async (list) => {
      db.exec('BEGIN');
      try {
        for (const [sql, p] of list) run(sql, p);
        db.exec('COMMIT');
      } catch (e) {
        db.exec('ROLLBACK');
        throw e;
      }
    },
    close: () => db.close(),
  };
}
