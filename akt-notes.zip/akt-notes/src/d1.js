// محوّل Cloudflare D1 — نفس واجهة محوّل SQLite المحلي.
export function d1Adapter(d1) {
  const prep = (sql, p = []) => d1.prepare(sql).bind(...p);
  return {
    all: async (sql, p) => (await prep(sql, p).all()).results,
    get: async (sql, p) => (await prep(sql, p).first()) ?? undefined,
    run: async (sql, p) => {
      const r = await prep(sql, p).run();
      return { changes: r.meta.changes, lastId: r.meta.last_row_id };
    },
    batch: async (list) => {
      await d1.batch(list.map(([sql, p]) => prep(sql, p)));
    },
  };
}
