// طبقة البيانات (async) فوق أي محوّل: SQLite محلي أو Cloudflare D1.
import { normalizeArabic, searchTerms, localDay, addDays } from './util.js';
import { hashPassword, sha256Hex, randomToken } from './crypto.js';

export const IMPORTANCE = { 1: 'عادية', 2: 'مهمة', 3: 'عاجلة' };

const SESSION_MS = 1000 * 60 * 60 * 24 * 14;

const NOTE_SELECT = `
  SELECT n.id, n.title, n.body, n.category_id, c.name AS category, n.importance,
         n.author_id, u.display_name AS author, n.pinned, n.archived,
         n.created_at, n.updated_at
    FROM notes n
    JOIN categories c ON c.id = n.category_id
    JOIN users u ON u.id = n.author_id`;

const shape = (r) =>
  r && { ...r, importance_label: IMPORTANCE[r.importance], pinned: !!r.pinned, archived: !!r.archived };

export function createStore(db, { timezone, pbkdf2Iterations = 100000 }) {
  const store = {
    /* --- المستخدمون --- */
    hasUsers: async () => (await db.get('SELECT COUNT(*) AS n FROM users')).n > 0,
    getUserByName: (name) => db.get('SELECT * FROM users WHERE username = ?', [name]),
    getUserById: (id) =>
      db.get('SELECT id, username, display_name, role, created_at FROM users WHERE id = ?', [id]),
    listUsers: () => db.all('SELECT id, username, display_name, role, created_at FROM users ORDER BY id'),
    async createUser({ username, displayName, password, role = 'user' }) {
      const hash = await hashPassword(password, pbkdf2Iterations);
      const info = await db.run(
        'INSERT INTO users (username, display_name, password_hash, role) VALUES (?,?,?,?)',
        [username, displayName, hash, role],
      );
      return store.getUserById(info.lastId);
    },

    /* --- الجلسات --- */
    async createSession(userId) {
      await db.run('DELETE FROM sessions WHERE expires_at < ?', [Date.now()]);
      const token = randomToken(32);
      await db.run('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?,?,?)', [
        await sha256Hex(token),
        userId,
        Date.now() + SESSION_MS,
      ]);
      return { token, maxAgeSec: SESSION_MS / 1000 };
    },
    async getSession(token) {
      if (!token) return null;
      const h = await sha256Hex(token);
      const row = await db.get(
        `SELECT u.id, u.username, u.display_name, u.role, s.expires_at
           FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?`,
        [h],
      );
      if (!row) return null;
      if (row.expires_at < Date.now()) {
        await db.run('DELETE FROM sessions WHERE token_hash = ?', [h]);
        return null;
      }
      const { expires_at, ...user } = row;
      return user;
    },
    async destroySession(token) {
      if (token) await db.run('DELETE FROM sessions WHERE token_hash = ?', [await sha256Hex(token)]);
    },

    /* --- تحديد المعدّل (مشترك بين كل النسخ عبر قاعدة البيانات) --- */
    async rateCount(key, windowMs) {
      return (await db.get('SELECT COUNT(*) AS n FROM rate_limits WHERE key = ? AND ts > ?', [key, Date.now() - windowMs])).n;
    },
    async rateAdd(key) {
      await db.run('INSERT INTO rate_limits (key, ts) VALUES (?, ?)', [key, Date.now()]);
      if (Math.random() < 0.05) await db.run('DELETE FROM rate_limits WHERE ts < ?', [Date.now() - 24 * 3600 * 1000]);
    },
    rateReset: (key) => db.run('DELETE FROM rate_limits WHERE key = ?', [key]),

    /* --- التصنيفات --- */
    listCategories: () =>
      db.all(
        `SELECT c.id, c.name, (SELECT COUNT(*) FROM notes n WHERE n.category_id = c.id AND n.archived = 0) AS count
           FROM categories c ORDER BY c.id`,
      ),
    getCategory: (id) => db.get('SELECT * FROM categories WHERE id = ?', [id]),
    async addCategory(name) {
      const existing = await db.get('SELECT * FROM categories WHERE name = ?', [name]);
      if (existing) return { category: existing, created: false };
      const info = await db.run('INSERT INTO categories (name) VALUES (?)', [name]);
      return { category: await store.getCategory(info.lastId), created: true };
    },

    /* --- الملاحظات --- */
    async getNote(id) {
      const note = shape(await db.get(NOTE_SELECT + ' WHERE n.id = ?', [id]));
      if (!note) return note;
      const ai = {};
      for (const r of await db.all(
        'SELECT kind, content, source_updated_at, created_at FROM ai_results WHERE note_id = ?',
        [note.id],
      )) {
        ai[r.kind] = { content: r.content, created_at: r.created_at, stale: r.source_updated_at !== note.updated_at };
      }
      return { ...note, ai };
    },
    async createNote({ title, body, categoryId, importance, authorId }) {
      const info = await db.run(
        'INSERT INTO notes (title, body, category_id, importance, author_id) VALUES (?,?,?,?,?)',
        [title, body, categoryId, importance, authorId],
      );
      return store.getNote(info.lastId);
    },
    async updateNote(id, { title, body, categoryId, importance }) {
      await db.run(
        `UPDATE notes SET title=?, body=?, category_id=?, importance=?,
           updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?`,
        [title, body, categoryId, importance, id],
      );
      return store.getNote(id);
    },
    async deleteNote(id) {
      return (await db.run('DELETE FROM notes WHERE id = ?', [id])).changes > 0;
    },
    async setPinned(id, v) {
      await db.run('UPDATE notes SET pinned = ? WHERE id = ?', [v ? 1 : 0, id]);
      return store.getNote(id);
    },
    async setArchived(id, v) {
      await db.run('UPDATE notes SET archived = ? WHERE id = ?', [v ? 1 : 0, id]);
      return store.getNote(id);
    },
    /** تطبيق صياغة محسّنة مع الاحتفاظ بالنص الأصلي في سجل النسخ (عملية ذرّية). */
    async applyRewrite(id, { title, body }) {
      const cur = await store.getNote(id);
      await db.batch([
        ['INSERT INTO note_revisions (note_id, title, body, reason) VALUES (?,?,?,?)', [id, cur.title, cur.body, 'before_ai_rewrite']],
        [
          `UPDATE notes SET title=?, body=?, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?`,
          [title ?? cur.title, body, id],
        ],
      ]);
      return store.getNote(id);
    },
    listRevisions: (id) =>
      db.all('SELECT id, title, body, reason, created_at FROM note_revisions WHERE note_id = ? ORDER BY id DESC', [id]),
    saveAiResult: (noteId, kind, content, sourceUpdatedAt) =>
      db.run(
        `INSERT INTO ai_results (note_id, kind, content, source_updated_at) VALUES (?,?,?,?)
           ON CONFLICT(note_id, kind) DO UPDATE SET content=excluded.content,
             source_updated_at=excluded.source_updated_at,
             created_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')`,
        [noteId, kind, content, sourceUpdatedAt],
      ),

    /**
     * قائمة الملاحظات مع الفلاتر. البحث يتم بعد توحيد النص العربي (همزات، تشكيل، أرقام).
     * range: today | week | month | all     view: active | archived | all
     */
    async listNotes({
      search = '', categoryId = null, range = 'all', view = 'active', importance = null,
      from = null, to = null, limit = 500,
    } = {}) {
      const where = [];
      const params = [];
      if (view === 'active') where.push('n.archived = 0');
      else if (view === 'archived') where.push('n.archived = 1');
      if (categoryId) { where.push('n.category_id = ?'); params.push(categoryId); }
      if (importance) { where.push('n.importance = ?'); params.push(importance); }
      const rows = (
        await db.all(
          NOTE_SELECT + (where.length ? ' WHERE ' + where.join(' AND ') : '') +
            ' ORDER BY n.pinned DESC, n.created_at DESC, n.id DESC',
          params,
        )
      ).map(shape);

      const today = localDay(new Date(), timezone);
      let lo = from;
      let hi = to;
      if (range === 'today') lo = hi = today;
      else if (range === 'week') { lo = addDays(today, -6); hi = today; }
      else if (range === 'month') { lo = addDays(today, -29); hi = today; }
      const terms = searchTerms(search);

      const out = [];
      for (const n of rows) {
        const day = localDay(new Date(n.created_at), timezone);
        if (lo && day < lo) continue;
        if (hi && day > hi) continue;
        if (terms.length) {
          const hay = normalizeArabic([n.title, n.body, n.category, n.author, day, n.importance_label].join(' \n '));
          if (!terms.every((t) => hay.includes(t))) continue;
        }
        out.push({ ...n, ai: {} });
        if (out.length >= limit) break;
      }
      return out;
    },

    async stats() {
      const today = localDay(new Date(), timezone);
      const all = await db.all('SELECT id, created_at, importance, pinned, category_id FROM notes WHERE archived = 0');
      const archived = (await db.get('SELECT COUNT(*) AS n FROM notes WHERE archived = 1')).n;
      return {
        total: all.length,
        today: all.filter((n) => localDay(new Date(n.created_at), timezone) === today).length,
        important: all.filter((n) => n.importance >= 2 || n.pinned).length,
        archived,
        by_category: await store.listCategories(),
        latest: await store.listNotes({ limit: 5 }),
      };
    },
  };
  return store;
}
