// إعدادات تعمل على Node وعلى Cloudflare Workers (بدون أي اعتماد على نظام الملفات).
export function loadConfig(env = {}) {
  const timezone = env.APP_TIMEZONE || 'Africa/Cairo';
  try {
    new Intl.DateTimeFormat('en', { timeZone: timezone });
  } catch {
    throw new Error(`APP_TIMEZONE غير صالح: ${timezone}`);
  }
  return {
    port: Number(env.PORT) || 3000,
    host: env.HOST || '127.0.0.1',
    timezone,
    trustProxy: env.TRUST_PROXY === 'true',
    // 'true' | 'false' | undefined (تلقائي حسب نوع الاتصال)
    cookieSecure: env.COOKIE_SECURE,
    // رمز يُطلب لإنشاء حساب المدير الأول (مهم عند النشر العام)
    setupCode: (env.SETUP_CODE || '').trim(),
    requireSetupCode: env.REQUIRE_SETUP_CODE === 'true',
    pbkdf2Iterations: Math.min(100000, Number(env.PBKDF2_ITERATIONS) || 100000),
    ai: {
      apiKey: (env.ANTHROPIC_API_KEY || '').trim(),
      model: env.AI_MODEL || 'claude-sonnet-5-5',
      baseUrl: (env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com').replace(/\/+$/, ''),
      timeoutMs: Number(env.AI_TIMEOUT_MS) || 60000,
    },
  };
}
