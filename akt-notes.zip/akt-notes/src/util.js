const ARABIC_INDIC = '٠١٢٣٤٥٦٧٨٩';
const EXT_ARABIC_INDIC = '۰۱۲۳۴۵۶۷۸۹';

/** توحيد النص العربي لأغراض البحث: إزالة التشكيل والتطويل وتوحيد الهمزات والتاء المربوطة والأرقام. */
export function normalizeArabic(input) {
  return String(input ?? '')
    .normalize('NFKC')
    .replace(/[ً-ٰٟـ]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ئ/g, 'ي')
    .replace(/ؤ/g, 'و')
    .replace(/ة/g, 'ه')
    .replace(/[٠-٩]/g, (d) => String(ARABIC_INDIC.indexOf(d)))
    .replace(/[۰-۹]/g, (d) => String(EXT_ARABIC_INDIC.indexOf(d)))
    .toLowerCase();
}

export function searchTerms(text) {
  return normalizeArabic(text)
    .split(/[\s،,؛;؟?!.:()\[\]{}"'«»]+/u)
    .map((t) => t.trim())
    .filter(Boolean);
}

export function likeEscape(s) {
  return s.replace(/[\\%_]/g, (m) => '\\' + m);
}

export function localDay(date, timeZone) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
}

export function localTime(date, timeZone) {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(date);
}

export function addDays(day, n) {
  const d = new Date(day + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

export function isDay(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(s + 'T00:00:00Z');
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}

export function weekdayAr(day) {
  return new Date(day + 'T12:00:00Z').toLocaleDateString('ar-EG', {
    weekday: 'long',
    timeZone: 'UTC',
  });
}
