#!/usr/bin/env bash
# نسخة احتياطية آمنة لقاعدة البيانات. جدولها يوميًا بـ cron:  0 3 * * * /path/backup.sh
set -euo pipefail
OUT="${1:-./backups}"; mkdir -p "$OUT"
F="$OUT/akt-notes-$(date +%F-%H%M).db"
docker compose exec -T app node --disable-warning=ExperimentalWarning -e "
const {DatabaseSync}=require('node:sqlite');
const d=new DatabaseSync('/app/data/akt-notes.db');d.exec(\"VACUUM INTO '/app/data/backup.tmp'\");" 
docker compose cp app:/app/data/backup.tmp "$F"
docker compose exec -T app rm -f /app/data/backup.tmp
find "$OUT" -name 'akt-notes-*.db' -mtime +30 -delete
echo "تم: $F"
