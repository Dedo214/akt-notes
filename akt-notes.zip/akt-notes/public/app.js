'use strict';
/* AKT Group Office Notes AI — الواجهة الأمامية. كل النصوص تُعرض عبر textContent (لا innerHTML لبيانات المستخدم). */

const LOGO_SVG =
  '<svg viewBox="0 0 64 64" aria-hidden="true"><path d="M12 46 32 12l20 34h-10l-10-18-10 18z" fill="#c9a24b"/><rect x="16" y="50" width="32" height="4" rx="2" fill="#0b1f3a"/></svg>';

const state = {
  user: null,
  meta: null,
  view: 'dashboard', // dashboard | notes | archive | ask
  filters: { search: '', range: 'all', category: '', importance: '' },
  chat: [],
};

/* ---------- أدوات ---------- */

function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'text') el.textContent = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'value' || k === 'checked' || k === 'disabled' || k === 'selected') el[k] = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}
const $ = (s, r = document) => r.querySelector(s);

class ApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

async function api(method, url, body) {
  let res;
  try {
    res = await fetch(url, {
      method,
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'akt' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new ApiError(0, 'network', 'تعذر الاتصال بالخادم. تحقق من الاتصال.');
  }
  let data = {};
  try {
    data = await res.json();
  } catch {
    /* بدون جسم */
  }
  if (!res.ok) {
    if (res.status === 401 && state.user && !url.startsWith('/api/auth/')) {
      state.user = null;
      boot();
    }
    throw new ApiError(res.status, data.error, data.message || 'حدث خطأ غير متوقع');
  }
  return data;
}

function toast(msg, isError = false) {
  const t = h('div', { class: 'toast' + (isError ? ' error' : ''), role: 'status', text: msg });
  $('#toasts').append(t);
  setTimeout(() => t.remove(), isError ? 6000 : 3000);
}

const tz = () => state.meta?.timezone || 'Africa/Cairo';
function fmtDateTime(iso) {
  return new Intl.DateTimeFormat('ar-EG-u-nu-latn', {
    timeZone: tz(), year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: true,
  }).format(new Date(iso));
}
function fmtNow() {
  return fmtDateTime(new Date().toISOString());
}

function debounce(fn, ms) {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
}

/** يعرض نص الذكاء الاصطناعي (عناوين تنتهي بنقطتين + نقاط بشرطة) بأمان. */
function rich(text) {
  const box = h('div', { class: 'rich' });
  let ul = null;
  for (const raw of String(text).split('\n')) {
    const line = raw.trim();
    if (!line) { ul = null; continue; }
    const bullet = line.match(/^[-•*]\s+(.*)$/);
    if (bullet) {
      if (!ul) { ul = h('ul'); box.append(ul); }
      ul.append(h('li', { text: bullet[1] }));
    } else {
      ul = null;
      box.append(h('p', { class: /[:：]$/.test(line) && line.length < 40 ? 'h' : '', text: line }));
    }
  }
  return box;
}

function button(label, onclick, cls = '', extra = {}) {
  return h('button', { type: 'button', class: 'btn ' + cls, onclick, ...extra }, label);
}

/** يشغّل دالة غير متزامنة مع تعطيل الزر وإظهار مؤشر تحميل. */
async function withBusy(btn, fn) {
  const old = Array.from(btn.childNodes);
  btn.disabled = true;
  btn.replaceChildren(h('span', { class: 'spinner' }), ' جارٍ التنفيذ…');
  try {
    return await fn();
  } finally {
    btn.disabled = false;
    btn.replaceChildren(...old);
  }
}

/* ---------- النوافذ ---------- */

function openModal({ title, body, footer, onClose }) {
  const root = $('#modal-root');
  const close = () => {
    overlay.remove();
    document.removeEventListener('keydown', onKey);
    if (!root.children.length) document.body.style.overflow = '';
    onClose?.();
  };
  const onKey = (e) => {
    if (e.key === 'Escape' && root.lastElementChild === overlay) close();
  };
  const overlay = h('div', { class: 'overlay', onmousedown: (e) => e.target === overlay && close() },
    h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
      h('div', { class: 'modal-head' },
        h('h2', { text: title }),
        h('button', { type: 'button', class: 'modal-x', 'aria-label': 'إغلاق', onclick: close, text: '×' })),
      h('div', { class: 'modal-body' }, body),
      footer ? h('div', { class: 'modal-foot' }, footer) : null));
  root.append(overlay);
  document.body.style.overflow = 'hidden';
  document.addEventListener('keydown', onKey);
  return { close, overlay };
}

/* ---------- الدخول / الإعداد ---------- */

function renderAuth(hasUsers, codeRequired = false) {
  const app = $('#app');
  const setup = !hasUsers;
  const err = h('div', { class: 'notice error', hidden: true });
  const f = {
    display: h('input', { class: 'input', autocomplete: 'name', maxlength: 60 }),
    username: h('input', { class: 'input', autocomplete: 'username', autocapitalize: 'none', maxlength: 30, dir: 'ltr' }),
    password: h('input', { class: 'input', type: 'password', autocomplete: setup ? 'new-password' : 'current-password', dir: 'ltr' }),
    code: h('input', { class: 'input', type: 'password', autocomplete: 'off', dir: 'ltr' }),
  };
  const submit = h('button', { class: 'btn btn-gold', type: 'submit', style: null }, setup ? 'إنشاء حساب المدير' : 'تسجيل الدخول');
  const form = h('form', {
    onsubmit: async (e) => {
      e.preventDefault();
      err.hidden = true;
      try {
        await withBusy(submit, async () => {
          const body = { username: f.username.value, password: f.password.value };
          if (setup) { body.display_name = f.display.value; if (codeRequired) body.setup_code = f.code.value; }
          const r = await api('POST', setup ? '/api/auth/setup' : '/api/auth/login', body);
          state.user = r.user;
        });
        await boot();
      } catch (ex) {
        err.textContent = ex.message;
        err.hidden = false;
      }
    },
  },
    setup ? h('div', { class: 'notice' }, 'أول استخدام: أنشئ حساب المدير. يمكنك لاحقًا إضافة بقية موظفي المكتب.') : null,
    err,
    setup ? h('div', { class: 'field' }, h('label', { text: 'الاسم الظاهر (يُسجَّل على الملاحظات)' }), f.display) : null,
    h('div', { class: 'field' }, h('label', { text: 'اسم المستخدم' }), f.username),
    h('div', { class: 'field' }, h('label', { text: setup ? 'كلمة المرور (8 أحرف على الأقل)' : 'كلمة المرور' }), f.password),
    setup && codeRequired ? h('div', { class: 'field' }, h('label', { text: 'رمز الإعداد (SETUP_CODE الذي ضبطته على الخادم)' }), f.code) : null,
    submit);
  submit.classList.add('btn-block');
  submit.style.width = '100%';
  app.replaceChildren(
    h('div', { class: 'auth-wrap' },
      h('div', { class: 'auth-card' },
        h('div', { class: 'brand-mark', html: null }),
        h('h1', { text: 'AKT Group' }),
        h('div', { class: 'sub', text: 'دفتر ملاحظات المكتب الذكي' }),
        form)));
  $('.auth-card .brand-mark').innerHTML = LOGO_SVG;
  (setup ? f.display : f.username).focus();
}

/* ---------- الهيكل الرئيسي ---------- */

const TABS = [
  ['dashboard', 'لوحة التحكم'],
  ['notes', 'الملاحظات'],
  ['archive', 'الأرشيف'],
  ['ask', 'اسأل ملاحظاتك'],
];

function renderShell() {
  const app = $('#app');
  const menuList = h('div', { class: 'menu-list', hidden: true },
    h('div', { class: 'readonly-box', text: state.user.role === 'admin' ? 'مدير' : 'مستخدم' }),
    state.user.role === 'admin' ? h('button', { type: 'button', onclick: () => { menuList.hidden = true; openUsers(); }, text: 'مستخدمو المكتب' }) : null,
    h('button', {
      type: 'button',
      onclick: async () => {
        try { await api('POST', '/api/auth/logout', {}); } catch { /* تجاهل */ }
        state.user = null;
        state.chat = [];
        boot();
      },
      text: 'تسجيل الخروج',
    }));
  const chip = h('button', { type: 'button', class: 'user-chip', 'aria-haspopup': 'true', onclick: () => (menuList.hidden = !menuList.hidden) }, '👤 ', state.user.display_name, ' ▾');
  document.addEventListener('click', (e) => { if (!e.target.closest('.menu')) menuList.hidden = true; });

  const logo = h('span', { class: 'brand-mark' });
  logo.innerHTML = LOGO_SVG;
  const tabs = h('nav', { class: 'tabs', 'aria-label': 'التنقل' },
    TABS.map(([id, label]) => h('button', { type: 'button', class: 'tab', 'data-tab': id, onclick: () => go(id), text: label })));

  app.replaceChildren(
    h('header', { class: 'topbar' },
      h('div', { class: 'topbar-inner' },
        h('div', { class: 'brand' }, logo,
          h('div', { class: 'brand-text' },
            h('div', { class: 'brand-name' }, 'AKT ', h('span', { text: 'Group' })),
            h('div', { class: 'brand-sub', text: 'دفتر ملاحظات المكتب الذكي' }))),
        h('div', { class: 'menu' }, chip, menuList)),
      tabs),
    h('main', { id: 'main' }),
    h('button', { type: 'button', class: 'btn btn-gold fab', onclick: () => openEditor(), text: '＋ ملاحظة جديدة' }));
}

function go(view) {
  state.view = view;
  document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === view));
  render();
}

async function render() {
  const main = $('#main');
  if (!main) return;
  main.replaceChildren(h('div', { class: 'empty', text: 'جارٍ التحميل…' }));
  try {
    if (state.view === 'dashboard') await renderDashboard(main);
    else if (state.view === 'ask') renderAsk(main);
    else await renderNotesPage(main);
  } catch (e) {
    main.replaceChildren(h('div', { class: 'notice error', text: e.message }));
  }
}

async function refreshMeta() {
  state.meta = await api('GET', '/api/meta');
}

/* ---------- لوحة التحكم ---------- */

async function renderDashboard(main) {
  const [s] = await Promise.all([api('GET', '/api/stats'), refreshMeta()]);
  const max = Math.max(1, ...s.by_category.map((c) => c.count));
  main.replaceChildren(
    h('div', { class: 'page-title' },
      h('h1', { text: `مرحبًا ${state.user.display_name}` }),
      button('＋ إضافة ملاحظة جديدة', () => openEditor(), 'btn-gold')),
    h('div', { class: 'grid-stats' },
      stat(s.total, 'إجمالي الملاحظات'),
      stat(s.today, 'ملاحظات اليوم'),
      stat(s.important, 'الملاحظات المهمة'),
      stat(s.archived, 'في الأرشيف')),
    h('div', { class: 'two-col' },
      h('section', { class: 'card' },
        h('h2', { class: 'section-title', text: 'أحدث الملاحظات' }),
        s.latest.length
          ? h('div', { class: 'notes' }, s.latest.map(noteCard))
          : h('div', { class: 'empty', text: 'لا توجد ملاحظات بعد. ابدأ بإضافة أول ملاحظة.' })),
      h('section', { class: 'card' },
        h('h2', { class: 'section-title', text: 'الملاحظات حسب التصنيف' }),
        s.by_category.map((c) =>
          h('div', { class: 'cat-row' },
            h('span', { text: c.name }), h('strong', { text: c.count }),
            h('div', { class: 'cat-bar' }, (() => { const i = h('i'); i.style.width = `${(c.count / max) * 100}%`; return i; })()))))));
}
const stat = (n, l) => h('div', { class: 'stat' }, h('div', { class: 'n', text: n }), h('div', { class: 'l', text: l }));

/* ---------- قائمة الملاحظات ---------- */

function noteCard(n) {
  return h('button', {
    type: 'button',
    class: `note-card imp-${n.importance}${n.pinned ? ' pinned' : ''}`,
    onclick: () => openNote(n.id),
  },
    h('div', { class: 'note-title' }, n.pinned ? '📌' : null, h('span', { text: n.title })),
    h('p', { class: 'note-excerpt', text: n.body }),
    h('div', { class: 'meta' },
      h('span', { class: 'tag', text: n.category }),
      h('span', { class: `badge imp-${n.importance}`, text: n.importance_label }),
      h('span', { text: n.author }),
      h('span', { text: fmtDateTime(n.created_at) }),
      n.archived ? h('span', { text: '🗄 مؤرشفة' }) : null));
}

async function renderNotesPage(main) {
  await refreshMeta();
  const isArchive = state.view === 'archive';
  const f = state.filters;
  const list = h('div', { 'aria-live': 'polite' });

  const load = async () => {
    const p = new URLSearchParams({ view: isArchive ? 'archived' : 'active', range: f.range });
    if (f.search.trim()) p.set('search', f.search.trim());
    if (f.category) p.set('category', f.category);
    if (f.importance) p.set('importance', f.importance);
    try {
      const { notes } = await api('GET', '/api/notes?' + p);
      list.replaceChildren(
        notes.length
          ? h('div', { class: 'notes' }, notes.map(noteCard))
          : h('div', { class: 'empty', text: f.search || f.category || f.importance || f.range !== 'all' ? 'لا توجد ملاحظات مطابقة.' : isArchive ? 'الأرشيف فارغ.' : 'لا توجد ملاحظات بعد.' }));
    } catch (e) {
      list.replaceChildren(h('div', { class: 'notice error', text: e.message }));
    }
  };

  const search = h('input', {
    class: 'input', type: 'search', placeholder: 'ابحث في العنوان أو المحتوى أو التصنيف أو التاريخ (مثال: 2026-10-26)…',
    value: f.search, 'aria-label': 'بحث', oninput: debounce((e) => { f.search = e.target.value; load(); }, 250),
  });
  const rangeChips = h('div', { class: 'chips' },
    [['all', 'الكل'], ['today', 'اليوم'], ['week', 'الأسبوع'], ['month', 'الشهر']].map(([v, l]) =>
      h('button', {
        type: 'button', class: 'chip' + (f.range === v ? ' active' : ''), text: l,
        onclick: (e) => { f.range = v; rangeChips.querySelectorAll('.chip').forEach((c) => c.classList.remove('active')); e.target.classList.add('active'); load(); },
      })));
  const catSel = h('select', { class: 'select', 'aria-label': 'التصنيف', onchange: (e) => { f.category = e.target.value; load(); } },
    h('option', { value: '', text: 'كل التصنيفات' }),
    state.meta.categories.map((c) => h('option', { value: c.id, text: c.name, selected: String(c.id) === String(f.category) })));
  const impSel = h('select', { class: 'select', 'aria-label': 'الأهمية', onchange: (e) => { f.importance = e.target.value; load(); } },
    h('option', { value: '', text: 'كل الدرجات' }),
    Object.entries(state.meta.importance).map(([v, l]) => h('option', { value: v, text: l, selected: String(v) === String(f.importance) })));

  main.replaceChildren(
    h('div', { class: 'page-title' }, h('h1', { text: isArchive ? 'الأرشيف' : 'الملاحظات' }),
      isArchive ? null : button('＋ إضافة ملاحظة', () => openEditor(), 'btn-gold')),
    h('div', { class: 'toolbar' }, h('div', { class: 'search-row' }, search), h('div', { class: 'filters' }, rangeChips, catSel, impSel)),
    list);
  await load();
}

/* ---------- محرر الملاحظة ---------- */

function openEditor(note = null) {
  const cats = state.meta.categories;
  const title = h('input', { class: 'input', maxlength: 200, value: note?.title || '', placeholder: 'عنوان مختصر للملاحظة' });
  const body = h('textarea', { class: 'textarea', maxlength: 20000, placeholder: 'اكتب تفاصيل الملاحظة هنا…' });
  body.value = note?.body || '';
  const catSel = h('select', { class: 'select' });
  const fillCats = (selectedId) => {
    catSel.replaceChildren(...state.meta.categories.map((c) => h('option', { value: c.id, text: c.name, selected: c.id === selectedId })));
  };
  fillCats(note?.category_id ?? cats.find((c) => c.name === 'ملاحظات عامة')?.id ?? cats[0].id);
  const impSel = h('select', { class: 'select' },
    Object.entries(state.meta.importance).map(([v, l]) => h('option', { value: v, text: l, selected: Number(v) === (note?.importance ?? 1) })));

  const newCat = h('input', { class: 'input', maxlength: 50, placeholder: 'اسم التصنيف الجديد' });
  const addCatRow = h('div', { class: 'inline-add', hidden: true }, newCat,
    button('إضافة', async () => {
      const name = newCat.value.trim();
      if (!name) return;
      try {
        const { category } = await api('POST', '/api/categories', { name });
        await refreshMeta();
        fillCats(category.id);
        newCat.value = '';
        addCatRow.hidden = true;
        toast('تمت إضافة التصنيف');
      } catch (e) { toast(e.message, true); }
    }, 'btn-primary'));

  const err = h('div', { class: 'notice error', hidden: true });
  const save = button(note ? 'حفظ التعديلات' : 'حفظ الملاحظة', async () => {
    err.hidden = true;
    try {
      await withBusy(save, async () => {
        const payload = { title: title.value, body: body.value, category_id: Number(catSel.value), importance: Number(impSel.value) };
        const r = note ? await api('PUT', `/api/notes/${note.id}`, payload) : await api('POST', '/api/notes', payload);
        m.close();
        toast(note ? 'تم حفظ التعديلات' : 'تم حفظ الملاحظة');
        render();
        if (note) openNote(r.note.id);
      });
    } catch (e) { err.textContent = e.message; err.hidden = false; }
  }, 'btn-gold');

  const m = openModal({
    title: note ? 'تعديل الملاحظة' : 'ملاحظة جديدة',
    body: [
      err,
      h('div', { class: 'field' }, h('label', { text: 'عنوان الملاحظة' }), title),
      h('div', { class: 'field' }, h('label', { text: 'تفاصيل الملاحظة' }), body),
      h('div', { class: 'row2' },
        h('div', { class: 'field' }, h('label', { text: 'التصنيف' }), catSel,
          h('button', { type: 'button', class: 'link-btn', onclick: () => { addCatRow.hidden = !addCatRow.hidden; newCat.focus(); }, text: '＋ تصنيف جديد' }), addCatRow),
        h('div', { class: 'field' }, h('label', { text: 'درجة الأهمية' }), impSel)),
      h('div', { class: 'row2' },
        h('div', { class: 'field' }, h('label', { text: 'سُجّلت بواسطة' }), h('div', { class: 'readonly-box', text: note ? note.author : state.user.display_name })),
        h('div', { class: 'field' }, h('label', { text: 'تاريخ ووقت التسجيل' }), h('div', { class: 'readonly-box', text: note ? fmtDateTime(note.created_at) : `${fmtNow()} (تلقائي)` }))),
    ],
    footer: [button('إلغاء', () => m.close()), save],
  });
  title.focus();
}

/* ---------- عرض الملاحظة + أدوات الذكاء الاصطناعي ---------- */

async function openNote(id) {
  let note;
  try {
    ({ note } = await api('GET', `/api/notes/${id}`));
  } catch (e) { return toast(e.message, true); }
  const canEdit = state.user.role === 'admin' || note.author_id === state.user.id;

  const aiHost = h('div');
  const reviewHost = h('div');
  const errHost = h('div');

  const showErr = (e) => { errHost.replaceChildren(h('div', { class: 'notice error', text: e.message })); };

  const aiPanel = (kind, title, data, regen) =>
    h('div', { class: 'ai-box' },
      h('h3', {}, h('span', { text: `✨ ${title}` }),
        h('span', {},
          data.stale ? h('span', { class: 'stale', text: 'قديم: عُدّلت الملاحظة بعد التوليد ' }) : null,
          h('button', { type: 'button', class: 'link-btn', onclick: regen, text: 'إعادة التوليد' }))),
      rich(data.content));
  const drawAi = () => {
    aiHost.replaceChildren(
      note.ai.summary ? aiPanel('summary', 'ملخص الذكاء الاصطناعي', note.ai.summary, () => runAi('summary', true)) : null,
      note.ai.keypoints ? aiPanel('keypoints', 'النقاط المهمة', note.ai.keypoints, () => runAi('keypoints', true)) : null);
  };
  const runAi = async (kind, force = false) => {
    errHost.replaceChildren();
    try {
      const r = await api('POST', `/api/notes/${note.id}/ai/${kind}`, { force });
      note.ai[kind] = { content: r.content, stale: false, created_at: r.created_at };
      drawAi();
    } catch (e) { showErr(e); }
  };

  const sumBtn = button('✨ تلخيص بالذكاء الاصطناعي', () => withBusy(sumBtn, () => runAi('summary')), 'btn-ai');
  const kpBtn = button('🔎 استخراج النقاط المهمة', () => withBusy(kpBtn, () => runAi('keypoints')), 'btn-ai');
  const rwBtn = canEdit ? button('📝 تحسين الصياغة', () => withBusy(rwBtn, async () => {
    errHost.replaceChildren();
    try {
      const r = await api('POST', `/api/notes/${note.id}/ai/rewrite`, {});
      showReview(r);
    } catch (e) { showErr(e); }
  }), 'btn-ai') : null;

  function showReview(r) {
    const t = h('input', { class: 'input', value: r.proposal.title, maxlength: 200 });
    const b = h('textarea', { class: 'textarea' });
    b.value = r.proposal.body;
    const apply = button('✔ اعتماد الصياغة الجديدة', () => withBusy(apply, async () => {
      try {
        await api('POST', `/api/notes/${note.id}/rewrite/apply`, { title: t.value, body: b.value });
        toast('تم اعتماد الصياغة. النص الأصلي محفوظ في سجل النسخ.');
        m.close();
        render();
        openNote(note.id);
      } catch (e) { showErr(e); }
    }), 'btn-gold');
    reviewHost.replaceChildren(
      h('div', { class: 'ai-box' },
        h('h3', { text: '📝 مراجعة الصياغة المقترحة (لم تُحفظ بعد)' }),
        h('div', { class: 'compare' },
          h('div', {}, h('h4', { text: 'النص الأصلي' }),
            h('div', { class: 'box' }, h('strong', { text: r.original.title }), '\n\n', r.original.body)),
          h('div', {}, h('h4', { text: 'الصياغة المقترحة (يمكنك تعديلها)' }), t, b)),
        h('div', { class: 'actions' }, apply, button('إلغاء واحتفاظ بالأصل', () => reviewHost.replaceChildren()))));
    reviewHost.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  const pinBtn = canEdit ? button(note.pinned ? '📌 إلغاء التثبيت' : '📌 تثبيت', async () => {
    try { await api('POST', `/api/notes/${note.id}/pin`, { value: !note.pinned }); m.close(); render(); } catch (e) { toast(e.message, true); }
  }) : null;
  const arcBtn = canEdit ? button(note.archived ? '↩ إلغاء الأرشفة' : '🗄 أرشفة', async () => {
    try { await api('POST', `/api/notes/${note.id}/archive`, { value: !note.archived }); m.close(); toast(note.archived ? 'تم الاسترجاع من الأرشيف' : 'تمت الأرشفة'); render(); } catch (e) { toast(e.message, true); }
  }) : null;
  const delBtn = canEdit ? button('🗑 حذف', async () => {
    if (!confirm('هل أنت متأكد من حذف هذه الملاحظة نهائيًا؟')) return;
    try { await api('DELETE', `/api/notes/${note.id}`); m.close(); toast('تم حذف الملاحظة'); render(); } catch (e) { toast(e.message, true); }
  }, 'btn-danger') : null;
  const editBtn = canEdit ? button('✏ تعديل', () => { m.close(); openEditor(note); }) : null;

  const m = openModal({
    title: note.title,
    body: [
      h('div', { class: 'meta' },
        h('span', { class: 'tag', text: note.category }),
        h('span', { class: `badge imp-${note.importance}`, text: note.importance_label }),
        h('span', { text: `سجّلها: ${note.author}` }),
        h('span', { text: fmtDateTime(note.created_at) }),
        note.updated_at !== note.created_at ? h('span', { text: `آخر تعديل: ${fmtDateTime(note.updated_at)}` }) : null,
        note.pinned ? h('span', { text: '📌 مثبّتة' }) : null,
        note.archived ? h('span', { text: '🗄 مؤرشفة' }) : null),
      h('div', { class: 'note-full', text: note.body }),
      h('div', { class: 'actions' }, editBtn, pinBtn, arcBtn, delBtn),
      h('div', { class: 'section-title', text: 'AKT AI Notes Assistant' }),
      state.meta.ai.configured ? null : h('div', { class: 'notice', text: 'خدمة الذكاء الاصطناعي غير مُعدّة بعد (يلزم ضبط ANTHROPIC_API_KEY في الخادم). لن تُرسل الملاحظة إلى أي جهة.' }),
      h('div', { class: 'actions' }, sumBtn, rwBtn, kpBtn),
      errHost, aiHost, reviewHost,
    ],
  });
  drawAi();
}

/* ---------- اسأل ملاحظاتك ---------- */

const SUGGESTIONS = [
  'ما الملاحظات التي سجلتها اليوم؟',
  'لخص ملاحظاتي الخاصة بالأسبوع',
  'ما الملاحظات التي تحتوي على مبالغ مالية؟',
  'ما آخر ملاحظة بخصوص الحسابات؟',
  'هل سجلت ملاحظات عن اجتماع؟',
];

function renderAsk(main) {
  const log = h('div', { class: 'chat', 'aria-live': 'polite' });
  const input = h('textarea', { class: 'textarea', maxlength: 500, rows: 1, placeholder: 'اكتب سؤالك عن ملاحظاتك المحفوظة…', 'aria-label': 'السؤال' });
  const sendBtn = h('button', { type: 'submit', class: 'btn btn-primary', text: 'اسأل' });

  const drawMsg = (m) => {
    if (m.kind === 'user') return h('div', { class: 'msg user', text: m.text });
    if (m.kind === 'err') return h('div', { class: 'msg err', text: m.text });
    return h('div', { class: 'msg bot' }, m.text,
      m.notes?.length ? h('div', { class: 'refs' }, h('span', { class: 'meta', text: 'الملاحظات المرجعية:' }),
        m.notes.map((n) => h('button', { type: 'button', class: 'ref', onclick: () => openNote(n.id), text: `${n.title} — ${fmtDateTime(n.created_at)}` }))) : null);
  };
  const draw = () => {
    log.replaceChildren(...state.chat.map(drawMsg));
    if (!state.chat.length) log.append(h('div', { class: 'empty', text: 'اسأل عن أي شيء مكتوب في ملاحظاتك. تعتمد الإجابات على الملاحظات المحفوظة فقط، ولا يخترع المساعد معلومات.' }));
  };
  const ask = async (q) => {
    q = q.trim();
    if (!q) return;
    state.chat.push({ kind: 'user', text: q });
    input.value = '';
    draw();
    sendBtn.disabled = true;
    const wait = h('div', { class: 'msg bot', text: 'جارٍ البحث في ملاحظاتك…' });
    log.append(wait);
    wait.scrollIntoView({ block: 'nearest' });
    try {
      const r = await api('POST', '/api/ask', { question: q });
      state.chat.push({ kind: 'bot', text: r.answer, notes: r.notes });
    } catch (e) {
      state.chat.push({ kind: 'err', text: e.message });
    }
    sendBtn.disabled = false;
    draw();
    log.lastElementChild?.scrollIntoView({ block: 'nearest' });
  };

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ask(input.value); }
  });
  main.replaceChildren(
    h('div', { class: 'page-title' }, h('h1', { text: 'اسأل ملاحظاتك' })),
    state.meta?.ai?.configured === false ? h('div', { class: 'notice', text: 'خدمة الذكاء الاصطناعي غير مُعدّة بعد (ANTHROPIC_API_KEY). ستظهر رسالة توضيحية عند السؤال.' }) : null,
    h('div', { class: 'card' },
      h('div', { class: 'suggest' }, SUGGESTIONS.map((s) => h('button', { type: 'button', class: 'chip', text: s, onclick: () => ask(s) }))),
      log,
      h('form', { class: 'ask-form', onsubmit: (e) => { e.preventDefault(); ask(input.value); } }, input, sendBtn)));
  draw();
  input.focus();
}

/* ---------- المستخدمون (للمدير) ---------- */

async function openUsers() {
  const list = h('div');
  const err = h('div', { class: 'notice error', hidden: true });
  const f = {
    display: h('input', { class: 'input', maxlength: 60, placeholder: 'الاسم الظاهر' }),
    username: h('input', { class: 'input', maxlength: 30, dir: 'ltr', autocapitalize: 'none', placeholder: 'اسم المستخدم (إنجليزي)' }),
    password: h('input', { class: 'input', type: 'password', dir: 'ltr', placeholder: 'كلمة المرور (8+ أحرف)', autocomplete: 'new-password' }),
    role: h('select', { class: 'select' }, h('option', { value: 'user', text: 'مستخدم' }), h('option', { value: 'admin', text: 'مدير' })),
  };
  const load = async () => {
    const { users } = await api('GET', '/api/users');
    list.replaceChildren(...users.map((u) => h('div', { class: 'user-row' }, h('strong', { text: u.display_name }), h('span', { class: 'meta', text: `${u.username} — ${u.role === 'admin' ? 'مدير' : 'مستخدم'}` }))));
  };
  const add = button('إضافة مستخدم', async () => {
    err.hidden = true;
    try {
      await api('POST', '/api/users', { display_name: f.display.value, username: f.username.value, password: f.password.value, role: f.role.value });
      f.display.value = f.username.value = f.password.value = '';
      toast('تمت إضافة المستخدم');
      await load();
    } catch (e) { err.textContent = e.message; err.hidden = false; }
  }, 'btn-primary');
  openModal({
    title: 'مستخدمو المكتب',
    body: [list, h('div', { class: 'section-title', text: 'إضافة مستخدم جديد' }), err,
      h('div', { class: 'row2' }, h('div', { class: 'field' }, f.display), h('div', { class: 'field' }, f.username)),
      h('div', { class: 'row2' }, h('div', { class: 'field' }, f.password), h('div', { class: 'field' }, f.role)), add],
  });
  try { await load(); } catch (e) { toast(e.message, true); }
}

/* ---------- الإقلاع ---------- */

async function boot() {
  $('#modal-root').replaceChildren();
  try {
    const s = await api('GET', '/api/auth/state');
    if (!s.user) {
      state.user = null;
      return renderAuth(s.has_users, s.setup_code_required);
    }
    state.user = s.user;
    await refreshMeta();
    renderShell();
    go(state.view);
  } catch (e) {
    $('#app').replaceChildren(h('div', { class: 'auth-wrap' }, h('div', { class: 'auth-card' }, h('div', { class: 'notice error', text: e.message }))));
  }
}

boot();
